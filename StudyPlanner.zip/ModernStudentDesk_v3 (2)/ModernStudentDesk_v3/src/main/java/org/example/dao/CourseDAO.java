
package org.example.dao;

import org.example.DBHelper;
import org.example.model.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
    public List<Course> allForUser(int userId){
        List<Course> list = new ArrayList<>();
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id,name,code FROM courses WHERE user_id=? ORDER BY name")){
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) list.add(new Course(rs.getInt("id"), rs.getString("name"), rs.getString("code")));
        } catch (SQLException e){ e.printStackTrace(); }
        return list;
    }
    public List<Course> all(){ // fallback - all courses
        List<Course> list = new ArrayList<>();
        try (Connection conn = DBHelper.getInstance().getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT id,name,code FROM courses ORDER BY name")){
            while(rs.next()) list.add(new Course(rs.getInt("id"), rs.getString("name"), rs.getString("code")));
        } catch (SQLException e){ e.printStackTrace(); }
        return list;
    }
    public void add(String name, String code, int userId){
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO courses(name,code,user_id) VALUES(?,?,?)")){
            ps.setString(1,name); ps.setString(2,code); ps.setInt(3,userId); ps.executeUpdate();
        } catch (SQLException e){ e.printStackTrace(); }
    }

    public void update(Course course) {
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE courses SET name = ?, code = ? WHERE id = ?")) {
            ps.setString(1, course.getName());
            ps.setString(2, course.getCode());
            ps.setInt(3, course.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(int courseId) {
        try (Connection conn = DBHelper.getInstance().getConnection()) {
            // First, delete tasks associated with the course to maintain data integrity
            try (PreparedStatement psTasks = conn.prepareStatement("DELETE FROM tasks WHERE course_id = ?")) {
                psTasks.setInt(1, courseId);
                psTasks.executeUpdate();
            }
            // Then, delete the course itself
            try (PreparedStatement psCourse = conn.prepareStatement("DELETE FROM courses WHERE id = ?")) {
                psCourse.setInt(1, courseId);
                psCourse.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
