
package org.example.model;

public class Task {
    private int id;
    private String title;
    private String description;
    private String dueDate; // ISO date string
    private int courseId;
    private boolean done;
    private int userId;
    private String priority;

    public Task() {}
    public Task(int id, String title){ this.id=id; this.title=title; }
    public int getId(){ return id; } public void setId(int id){ this.id=id; }
    public String getTitle(){ return title; } public void setTitle(String title){ this.title=title; }
    public String getDescription(){ return description; } public void setDescription(String description){ this.description=description; }
    public String getDueDate(){ return dueDate; } public void setDueDate(String dueDate){ this.dueDate=dueDate; }
    public int getCourseId(){ return courseId; } public void setCourseId(int courseId){ this.courseId=courseId; }
    public boolean isDone(){ return done; } public void setDone(boolean done){ this.done=done; }
    public int getUserId(){ return userId; } public void setUserId(int userId){ this.userId=userId; }
    public String getPriority() { return priority; } public void setPriority(String priority) { this.priority = priority; }

    @Override
    public String toString() {
        String priorityStr = (priority != null && !priority.isEmpty()) ? " [" + priority + "]" : "";
        return title + priorityStr + (dueDate != null ? " — " + dueDate : "");
    }
}
