
package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import org.example.dao.AuthDAO;
import org.example.model.User;

import java.io.IOException;

public class LoginController {
    @FXML TextField usernameField;
    @FXML PasswordField passwordField;
    @FXML Label messageLabel;

    private AuthDAO authDAO = new AuthDAO();

    @FXML
    public void onSignIn() throws IOException {
        String u = usernameField.getText().trim();
        String p = passwordField.getText().trim();
        User user = authDAO.authenticate(u,p);
        if(user!=null){
            // open dashboard and pass user
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/dashboard.fxml"));
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Scene scene = new Scene(loader.load());
            org.example.controller.DashboardController dc = loader.getController();
            dc.setCurrentUser(user);
            stage.setScene(scene);
        } else {
            messageLabel.setText("Invalid credentials");
        }
    }

    @FXML
    public void onRegister(){
        String u = usernameField.getText().trim();
        String p = passwordField.getText().trim();
        if(u.isEmpty()||p.isEmpty()){ 
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Please enter both username and password.");
            return; 
        }
        boolean ok = authDAO.register(u,p);
        if(ok) {
            showAlert(Alert.AlertType.INFORMATION, "Registration Successful", "You have been registered! You can sign in now.");
        } else {
            showAlert(Alert.AlertType.ERROR, "Registration Failed", "Could not register. The username might already be taken.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
