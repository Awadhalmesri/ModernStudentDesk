
package org.example;

import java.sql.*;
import org.example.util.HashUtil;

public class DBHelper {
    private static final String DB_URL = "jdbc:sqlite:studentdesk.db";
    private static DBHelper instance;

    private DBHelper(){}

    public static DBHelper getInstance(){
        if(instance==null) instance = new DBHelper();
        return instance;
    }

    public void init(){
        try (Connection conn = getConnection(); Statement st = conn.createStatement()){
            // users
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL
                )
            """);
            // courses (per-user)
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS courses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    code TEXT,
                    user_id INTEGER,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """);
            // tasks (per-user)
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    due_date TEXT,
                    course_id INTEGER,
                    user_id INTEGER,
                    done INTEGER DEFAULT 0,
                    FOREIGN KEY(course_id) REFERENCES courses(id),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            """);

            // Add priority column to tasks table if it doesn't exist
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet columns = meta.getColumns(null, null, "tasks", "priority");
            if (!columns.next()) {
                st.executeUpdate("ALTER TABLE tasks ADD COLUMN priority TEXT");
            }

            // seed a demo user if none
            ResultSet rs = st.executeQuery("SELECT COUNT(*) as c FROM users");
            if(rs.next() && rs.getInt("c")==0){
                String demoUser = "demo";
                String demoPass = HashUtil.sha256("password");
                PreparedStatement p = conn.prepareStatement("INSERT INTO users(username,password) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS);
                p.setString(1, demoUser); p.setString(2, demoPass); p.executeUpdate();
                ResultSet g = p.getGeneratedKeys();
                int demoId = 0;
                if(g.next()) demoId = g.getInt(1);
                p.close();
                // optionally seed a sample course for demo user
                PreparedStatement pc = conn.prepareStatement("INSERT INTO courses(name,code,user_id) VALUES(?,?,?)");
                pc.setString(1, "Demo Course"); pc.setString(2, "DEM101"); pc.setInt(3, demoId); pc.executeUpdate();
                pc.close();
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}
