// Final, corrected, and feature-complete version
package org.example.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.example.dao.CourseDAO;
import org.example.dao.TaskDAO;
import org.example.model.Course;
import org.example.model.Task;
import org.example.model.User;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

public class DashboardController {
    @FXML private ListView<Course> courseList;
    @FXML private ListView<Task> taskList;
    @FXML private TextField taskFilter;
    @FXML private ChoiceBox<String> sortTasksChoiceBox;

    @FXML private Label monthLabel;
    @FXML private GridPane calendarGrid;
    @FXML private ListView<Task> dateTasksList;

    private final CourseDAO courseDAO = new CourseDAO();
    private final TaskDAO taskDAO = new TaskDAO();

    private YearMonth currentMonth = YearMonth.now();
    private User currentUser;

    public void setCurrentUser(User user) {
        this.currentUser = user;
        refreshCourses();
        refreshTasks();
        renderCalendar();
    }

    @FXML
    public void initialize() {
        // Initialize Sort ChoiceBox
        sortTasksChoiceBox.setItems(FXCollections.observableArrayList("Due Date", "Priority", "Title"));
        sortTasksChoiceBox.setValue("Due Date");
        sortTasksChoiceBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                sortTasks(newVal);
            }
        });

        // Initialize Course List Listener
        courseList.getSelectionModel().selectedItemProperty().addListener((obs, oldv, newv) -> {
            if (newv != null && currentUser != null) {
                taskFilter.clear();
                loadTasksForCourse(newv.getId());
            }
        });

        // Initialize Task List Cell Factory for custom rendering
        taskList.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Task item, boolean empty) {
                super.updateItem(item, empty);
                setStyle("");
                setText(null);
                setGraphic(null);

                if (empty || item == null) {
                    // No action for empty cells
                } else {
                    setText(item.toString());
                    String baseStyle = "";
                    if (item.isDone()) {
                        baseStyle = "-fx-strikethrough: true; -fx-text-fill: gray;";
                    } else if (item.getPriority() != null) {
                        switch (item.getPriority()) {
                            case "High":
                                baseStyle = "-fx-control-inner-background: #FFD2D2;"; // Light red
                                break;
                            case "Medium":
                                baseStyle = "-fx-control-inner-background: #FFF3CD;"; // Light orange
                                break;
                            case "Low":
                                baseStyle = "-fx-control-inner-background: #D4EDDA;"; // Light green
                                break;
                        }
                    }
                    setStyle(baseStyle);
                }
            }
        });
    }

    private void sortTasks(String sortBy) {
        List<Task> currentTasks = new ArrayList<>(taskList.getItems());
        Comparator<Task> comparator;

        switch (sortBy) {
            case "Priority":
                Map<String, Integer> priorityOrder = Map.of("High", 1, "Medium", 2, "Low", 3);
                comparator = Comparator.comparing(t -> priorityOrder.getOrDefault(t.getPriority(), 4));
                break;
            case "Title":
                comparator = Comparator.comparing(Task::getTitle, String.CASE_INSENSITIVE_ORDER);
                break;
            default: // "Due Date"
                comparator = Comparator.comparing(Task::getDueDate, Comparator.nullsLast(Comparator.naturalOrder()));
                break;
        }
        currentTasks.sort(comparator);
        taskList.setItems(FXCollections.observableArrayList(currentTasks));
    }

    private void refreshCourses() {
        if (currentUser == null) return;
        courseList.setItems(FXCollections.observableArrayList(courseDAO.allForUser(currentUser.getId())));
    }

    private void refreshTasks() {
        if (currentUser == null) return;
        taskList.setItems(FXCollections.observableArrayList(taskDAO.allForUser(currentUser.getId())));
        sortTasks(sortTasksChoiceBox.getValue());
        renderCalendar();
    }

    private void loadTasksForCourse(int courseId) {
        var all = taskDAO.allForUser(currentUser.getId());
        var filtered = all.stream().filter(t -> t.getCourseId() == courseId).collect(Collectors.toList());
        taskList.setItems(FXCollections.observableArrayList(filtered));
        sortTasks(sortTasksChoiceBox.getValue());
    }

    public void onAddCourse() {
        if (currentUser == null) { showInfo("No user"); return; }
        TextInputDialog d = new TextInputDialog();
        d.setTitle("Add Course");
        d.setHeaderText("Enter course name (optional code with a comma)");
        d.setContentText("Name,Code:");
        Optional<String> res = d.showAndWait();
        res.ifPresent(s -> {
            String[] parts = s.split(",", 2);
            String name = parts[0].trim();
            String code = parts.length > 1 ? parts[1].trim() : null;
            if (!name.isEmpty()) {
                courseDAO.add(name, code, currentUser.getId());
                refreshCourses();
            }
        });
    }

    public void onEditCourse() {
        Course selected = courseList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a course to edit.");
            return;
        }

        TextInputDialog d = new TextInputDialog(selected.getName() + (selected.getCode() != null ? ", " + selected.getCode() : ""));
        d.setTitle("Edit Course");
        d.setHeaderText("Enter course name (optional code with a comma)");
        d.setContentText("Name,Code:");
        Optional<String> res = d.showAndWait();
        res.ifPresent(s -> {
            String[] parts = s.split(",", 2);
            String name = parts[0].trim();
            String code = parts.length > 1 ? parts[1].trim() : null;
            if (!name.isEmpty()) {
                selected.setName(name);
                selected.setCode(code);
                courseDAO.update(selected);
                refreshCourses();
            }
        });
    }

    public void onDeleteCourse() {
        Course selected = courseList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showInfo("Please select a course to delete.");
            return;
        }
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete Course");
        alert.setHeaderText("Delete '" + selected.getName() + "'?");
        alert.setContentText("This will also delete all tasks associated with this course.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            courseDAO.delete(selected.getId());
            refreshCourses();
            refreshTasks();
        }
    }

    private void showTaskDialog(Task task) {
        boolean isEdit = (task != null);
        Dialog<Task> dialog = new Dialog<>();
        dialog.setTitle(isEdit ? "Edit Task" : "Add Task");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane gp = new GridPane(); gp.setHgap(8); gp.setVgap(8);
        TextField title = new TextField(isEdit ? task.getTitle() : ""); title.setPromptText("Title");
        TextField due = new TextField(isEdit && task.getDueDate() != null ? task.getDueDate() : ""); due.setPromptText("YYYY-MM-DD");
        TextArea desc = new TextArea(isEdit ? task.getDescription() : "");
        ComboBox<Course> courseCb = new ComboBox<>(FXCollections.observableArrayList(courseDAO.allForUser(currentUser.getId())));
        if (isEdit) courseCb.getSelectionModel().select(courseDAO.allForUser(currentUser.getId()).stream().filter(c -> c.getId() == task.getCourseId()).findFirst().orElse(null));
        ComboBox<String> priorityCb = new ComboBox<>(FXCollections.observableArrayList("Low", "Medium", "High"));
        if (isEdit) priorityCb.setValue(task.getPriority());

        gp.add(new Label("Title:"), 0, 0); gp.add(title, 1, 0);
        gp.add(new Label("Due Date:"), 0, 1); gp.add(due, 1, 1);
        gp.add(new Label("Course:"), 0, 2); gp.add(courseCb, 1, 2);
        gp.add(new Label("Priority:"), 0, 3); gp.add(priorityCb, 1, 3);
        gp.add(new Label("Description:"), 0, 4); gp.add(desc, 1, 4);
        dialog.getDialogPane().setContent(gp);

        final Button btOk = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
        btOk.addEventFilter(javafx.event.ActionEvent.ACTION, event -> {
            if (title.getText().trim().isEmpty()) {
                showInfo("Title cannot be empty.");
                event.consume();
            } else if (!due.getText().trim().isEmpty()) {
                try {
                    LocalDate.parse(due.getText().trim());
                } catch (DateTimeParseException e) {
                    showInfo("Invalid date format. Please use YYYY-MM-DD.");
                    event.consume();
                }
            }
        });

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                Task resultTask = isEdit ? task : new Task();
                resultTask.setTitle(title.getText().trim());
                resultTask.setDescription(desc.getText().trim());
                resultTask.setDueDate(due.getText().trim().isEmpty() ? null : due.getText().trim());
                Course c = courseCb.getValue();
                resultTask.setCourseId(c != null ? c.getId() : 0);
                if (!isEdit) resultTask.setUserId(currentUser.getId());
                resultTask.setPriority(priorityCb.getValue());
                return resultTask;
            }
            return null;
        });

        Optional<Task> res = dialog.showAndWait();
        res.ifPresent(t -> {
            if (isEdit) {
                taskDAO.update(t);
                showInfo("Task updated successfully.");
            } else {
                taskDAO.add(t);
                showInfo("Task added successfully.");
            }
            refreshTasks();
        });
    }

    public void onAddTask() {
        if (currentUser == null) { showInfo("No user"); return; }
        showTaskDialog(null);
    }

    public void onEditTask() {
        Task sel = taskList.getSelectionModel().getSelectedItem();
        if (sel == null) { showInfo("Select a task to edit"); return; }
        showTaskDialog(sel);
    }

    public void onDeleteTask() {
        Task sel = taskList.getSelectionModel().getSelectedItem();
        if (sel == null) { showInfo("Select a task to delete"); return; }
        Alert a = new Alert(AlertType.CONFIRMATION, "Delete selected task?", ButtonType.YES, ButtonType.NO);
        a.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            taskDAO.delete(sel.getId());
            refreshTasks();
        });
    }

    public void onToggleDone() {
        Task sel = taskList.getSelectionModel().getSelectedItem();
        if (sel == null) { showInfo("Select a task"); return; }
        sel.setDone(!sel.isDone());
        taskDAO.update(sel);
        refreshTasks();
    }

    public void onFilter() {
        courseList.getSelectionModel().clearSelection(); // Clear course selection when filtering by text
        String q = taskFilter.getText();
        if (currentUser == null) return;
        if (q.isEmpty()) {
            refreshTasks();
            return;
        }
        var all = taskDAO.allForUser(currentUser.getId());
        var filtered = all.stream().filter(t -> t.getTitle().toLowerCase().contains(q.toLowerCase()) || (t.getDescription() != null && t.getDescription().toLowerCase().contains(q.toLowerCase()))).toList();
        taskList.setItems(FXCollections.observableArrayList(filtered));
        sortTasks(sortTasksChoiceBox.getValue());
    }

    public void onReport() {
        if (currentUser == null) return;
        var courses = courseDAO.allForUser(currentUser.getId());
        StringBuilder sb = new StringBuilder();
        var tasks = taskDAO.allForUser(currentUser.getId());
        for (var c : courses) {
            long count = tasks.stream().filter(t -> t.getCourseId() == c.getId()).count();
            sb.append(c.getName()).append(" -> ").append(count).append(" tasks\n");
        }
        if (courses.isEmpty()) sb.append("No courses\n");
        Alert a = new Alert(AlertType.INFORMATION);
        a.setHeaderText("Tasks per course");
        a.setContentText(sb.toString());
        a.showAndWait();
    }

    public void onImport() {
        if (currentUser == null) return;
        FileChooser fc = new FileChooser();
        fc.setTitle("Import Tasks CSV");
        File f = fc.showOpenDialog(taskList.getScene().getWindow());
        if (f == null) return;
        try {
            var lines = Files.readAllLines(f.toPath());
            for (var line : lines) {
                var parts = line.split(",", 5);
                if (parts.length >= 2) {
                    Task t = new Task();
                    t.setTitle(parts[0].trim());
                    t.setDueDate(parts[1].trim().isEmpty() ? null : parts[1].trim());
                    t.setDescription(parts.length > 2 ? parts[2].trim() : "");
                    String cname = parts.length > 3 ? parts[3].trim() : "";
                    var course = courseDAO.allForUser(currentUser.getId()).stream().filter(c -> c.getName().equalsIgnoreCase(cname)).findFirst().orElse(null);
                    t.setCourseId(course != null ? course.getId() : 0);
                    t.setUserId(currentUser.getId());
                    taskDAO.add(t);
                }
            }
            refreshTasks();
            showInfo("Imported");
        } catch (Exception ex) {
            ex.printStackTrace();
            showInfo("Import failed: " + ex.getMessage());
        }
    }

    public void onExport() {
        if (currentUser == null) return;
        FileChooser fc = new FileChooser();
        fc.setTitle("Export Tasks CSV");
        File f = fc.showSaveDialog(taskList.getScene().getWindow());
        if (f == null) return;
        var tasks = taskDAO.allForUser(currentUser.getId());
        try (var pw = new PrintWriter(f)) {
            for (var t : tasks) {
                String cname = courseDAO.allForUser(currentUser.getId()).stream().filter(c -> c.getId() == t.getCourseId()).findFirst().map(Course::getName).orElse("");
                pw.println(String.join(",", escape(t.getTitle()), escape(t.getDueDate()), escape(t.getDescription()), escape(cname)));
            }
            showInfo("Exported");
        } catch (Exception ex) {
            ex.printStackTrace();
            showInfo("Export failed: " + ex.getMessage());
        }
    }

    private String escape(String s) { return s == null ? "" : s.replaceAll("\\,", ""); }

    private void showInfo(String msg) {
        Alert a = new Alert(AlertType.INFORMATION);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

    private void renderCalendar() {
        if (currentUser == null) return;
        calendarGrid.getChildren().clear();
        monthLabel.setText(currentMonth.getMonth().toString() + " " + currentMonth.getYear());
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        for (int i = 0; i < 7; i++) {
            Label l = new Label(days[i]);
            l.setStyle("-fx-font-weight:600;");
            calendarGrid.add(l, i, 0);
        }
        var tasks = taskDAO.allForUser(currentUser.getId());
        LocalDate first = currentMonth.atDay(1);
        int startCol = first.getDayOfWeek().getValue() - 1; // Monday is 1, so 0
        int daysInMonth = currentMonth.lengthOfMonth();
        int row = 1;
        int col = startCol;
        for (int d = 1; d <= daysInMonth; d++) {
            LocalDate day = currentMonth.atDay(d);
            VBox cell = new VBox();
            cell.setSpacing(4);
            cell.setStyle("-fx-padding:6; -fx-border-color:#eee; -fx-background-color:#fff;");
            Label dayLabel = new Label(String.valueOf(d));
            var dayTasks = tasks.stream().filter(t -> {
                try {
                    return t.getDueDate() != null && !t.getDueDate().isEmpty() && LocalDate.parse(t.getDueDate()).equals(day);
                } catch (Exception ex) {
                    return false;
                }
            }).collect(Collectors.toList());
            cell.getChildren().add(dayLabel);
            for (var dt : dayTasks) {
                Label tl = new Label(dt.getTitle());
                tl.setStyle("-fx-font-size:11px;");
                cell.getChildren().add(tl);
            }
            cell.setOnMouseClicked(ev -> dateTasksList.setItems(FXCollections.observableArrayList(dayTasks)));
            calendarGrid.add(cell, col, row);
            col++;
            if (col > 6) {
                col = 0;
                row++;
            }
        }
    }

    public void onPrevMonth() {
        currentMonth = currentMonth.minusMonths(1);
        renderCalendar();
    }

    public void onNextMonth() {
        currentMonth = currentMonth.plusMonths(1);
        renderCalendar();
    }

    public void onLogout() {
        try {
            var stage = (Stage) courseList.getScene().getWindow();
            var loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            stage.setScene(new Scene(loader.load()));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
