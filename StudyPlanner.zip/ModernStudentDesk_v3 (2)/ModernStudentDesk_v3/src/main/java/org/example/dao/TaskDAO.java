
package org.example.dao;

import org.example.DBHelper;
import org.example.model.Task;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {
    public List<Task> all(){
        List<Task> list = new ArrayList<>();
        try (Connection conn = DBHelper.getInstance().getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT id,title,description,due_date,course_id,user_id,done,priority FROM tasks ORDER BY due_date")){
            while(rs.next()){
                Task t = new Task();
                t.setId(rs.getInt("id"));
                t.setTitle(rs.getString("title"));
                t.setDescription(rs.getString("description"));
                t.setDueDate(rs.getString("due_date"));
                t.setCourseId(rs.getInt("course_id"));
                t.setDone(rs.getInt("done")!=0);
                t.setPriority(rs.getString("priority"));
                list.add(t);
            }
        } catch (SQLException e){ e.printStackTrace(); }
        return list;
    }

    public List<Task> allForUser(int userId){
        List<Task> list = new ArrayList<>();
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id,title,description,due_date,course_id,user_id,done,priority FROM tasks WHERE user_id=? ORDER BY due_date")){
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Task t = new Task();
                t.setId(rs.getInt("id"));
                t.setTitle(rs.getString("title"));
                t.setDescription(rs.getString("description"));
                t.setDueDate(rs.getString("due_date"));
                t.setCourseId(rs.getInt("course_id"));
                t.setDone(rs.getInt("done")!=0);
                t.setPriority(rs.getString("priority"));
                list.add(t);
            }
        } catch (SQLException e){ e.printStackTrace(); }
        return list;
    }

    public void add(Task t){
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO tasks(title,description,due_date,course_id,user_id,done,priority) VALUES(?,?,?,?,?,?,?)")){
            ps.setString(1, t.getTitle()); ps.setString(2, t.getDescription()); ps.setString(3, t.getDueDate());
            ps.setInt(4, t.getCourseId()); ps.setInt(5, t.getUserId());
            ps.setInt(6, t.isDone()?1:0);
            ps.setString(7, t.getPriority());
            ps.executeUpdate();
        } catch (SQLException e){ e.printStackTrace(); }
    }

    public void update(Task t){
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE tasks SET title=?,description=?,due_date=?,course_id=?,done=?,priority=? WHERE id=?")){
            ps.setString(1, t.getTitle()); ps.setString(2, t.getDescription()); ps.setString(3, t.getDueDate());
            ps.setInt(4, t.getCourseId()); ps.setInt(5, t.isDone()?1:0); ps.setString(6, t.getPriority()); ps.setInt(7, t.getId());
            ps.executeUpdate();
        } catch (SQLException e){ e.printStackTrace(); }
    }
    public void delete(int id){
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM tasks WHERE id=?")){
            ps.setInt(1, id); ps.executeUpdate();
        } catch (SQLException e){ e.printStackTrace(); }
    }

    // helper: find the owner (user_id) of a course to set as task.user_id when adding a task
    private int getCourseOwner(int courseId){
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT user_id FROM courses WHERE id=?")){
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) return rs.getInt("user_id");
        } catch (SQLException e){ e.printStackTrace(); }
        return 0;
    }
}
