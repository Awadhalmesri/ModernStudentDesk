
package org.example.dao;

import org.example.DBHelper;
import org.example.model.User;
import org.example.util.HashUtil;

import java.sql.*;

public class AuthDAO {
    public User authenticate(String username, String password){
        if(username==null || password==null) return null;
        String hashed = HashUtil.sha256(password);
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id,username,password FROM users WHERE username=? AND password=?")){
            ps.setString(1, username); ps.setString(2, hashed);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return new User(rs.getInt("id"), rs.getString("username"), rs.getString("password"));
            }
        } catch (SQLException e){ e.printStackTrace(); }
        return null;
    }

    public boolean register(String username, String password){
        if(username==null || password==null) return false;
        String hashed = HashUtil.sha256(password);
        try (Connection conn = DBHelper.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users(username,password) VALUES(?,?)")){
            ps.setString(1, username); ps.setString(2, hashed);
            ps.executeUpdate();
            return true;
        } catch (SQLException e){ e.printStackTrace(); return false; }
    }
}
