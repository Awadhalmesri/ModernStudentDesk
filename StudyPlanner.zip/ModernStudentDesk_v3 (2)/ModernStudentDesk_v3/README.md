
ModernStudentDesk
-----------------
A minimal JavaFX desktop app with SQLite local storage.

How to build & run (tested with JDK 17+ and Maven):
1. Unzip the project.
2. From the project root where pom.xml is located run:
   mvn javafx:run
3. Default demo user: username 'demo' password 'password'
Notes:
- This is a starting scaffold: add validation, nicer UI, more reporting as needed.
- The database file `studentdesk.db` will be created in the project root on first run.


Updated: Added calendar view, task edit/delete, import/export CSV. Requires JDK 17+


Updated v3: Passwords hashed with SHA-256, per-user courses/tasks. Use JDK 17+.
